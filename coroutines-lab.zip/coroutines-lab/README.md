# Laboratory 9 – Coroutines

All 15 questions are in one file: `src/main/kotlin/Main.kt` (functions `q1()` … `q15()`).
`main()` runs them one after another. Kotlin/JVM, `kotlinx-coroutines-core 1.10.2`.

---

## Question 1. First coroutine
```
Order accepted
Coffee ready
```
`launch` only starts the coroutine and returns at once. The coroutine waits one second, so the main body prints "Order accepted" first.

## Question 2. Three baristas
With `delay`:
```
espresso start
tea start
latte start
tea end
latte end
espresso end
```
With `Thread.sleep`:
```
espresso start
espresso end
tea start
tea end
latte start
latte end
```
With `delay` the thread is free while a coroutine waits, so the others run. With `Thread.sleep` the thread is blocked and nothing else can run.

## Question 3. Chain of suspend functions
```
Step 1: load user
Step 2: check password
Step 3: open profile
Profile opened
Login flow finished
```
Suspending does not reorder lines: inside one coroutine the code runs top to bottom, `delay` only pauses it.

## Question 4. Calling suspend from normal code
Compile error:
```
Suspend function 'fetchUser' should be called only from a coroutine or another suspend function.
```
Output:
```
Fix 1 (suspend): Ada
Fix 2 (runBlocking): Ada
```
Fix 1: make the caller `suspend`. Fix 2: use `runBlocking`.
Never use `runBlocking` on the Android UI thread: it blocks the thread, the screen freezes and the app can get an ANR.

## Question 5. Suspend is not a thread
```
Before the call: main
Returned: main
```
The belief is wrong: `suspend` does not move work to a background thread, the thread stays `main`.
The hidden parameter added by the compiler is `Continuation`.

## Question 6. Ten downloads, one thread
```
download 1 started on main
download 2 started on main
download 3 started on main
download 4 started on main
download 5 started on main
download 6 started on main
download 7 started on main
download 8 started on main
download 9 started on main
download 10 started on main
download 1 finished
download 2 finished
download 3 finished
download 4 finished
download 5 finished
download 6 finished
download 7 finished
download 8 finished
download 9 finished
download 10 finished
```
This is concurrency: all downloads make progress in the same period on one thread and take turns. Parallelism would need several threads working at the same moment.

## Question 7. Order of launch
```
1
4
2
5
3
```
`launch` only schedules the coroutine. The only thread is busy with the main body, so the child starts when the main body suspends (`delay(50)`). That is why "2" does not come right after "1".

## Question 8. Parent waits for child
```
parent body done
child done
report completed
```
Rule of structured concurrency: a parent is completed only after all its children are completed, so `join()` returns after "child done".

## Question 9. Screen closed, requests cancelled
```
request 1 started
request 2 started
request 1 cleanup
request 2 cleanup
end
```
Cancelling a parent cancels all its children too (cancellation goes down the tree), so both `finally` blocks run.

## Question 10. Profile ready
```
settings loaded
avatar loaded
Profile ready
end of main
late coroutine
```
`coroutineScope` waits for all its children before the next line runs. A plain `launch` does not wait, so the main body continues and prints "end of main" first.

## Question 11. Reusable counter
```
launched
A: 1
B: 1
A: 2
B: 2
A: 3
B: 3
B: 4
B: 5
```
`launch` is an extension of `CoroutineScope`. The receiver gives our function a scope to start the coroutine in, so the counter belongs to the caller's scope and the function returns at once with the `Job`.

## Question 12. Returns at once or waits
```
after greetInBackground
Hello, Linus
Hello, Grace
after greetAll
Hello, Ada (background)
```
`greetInBackground` returns at once (it only starts a coroutine). `greetAll` waits (`coroutineScope`) until all its greetings are printed.

## Question 13. Five builders
```
launch returned: StandaloneCoroutine
inside launch
async returned: DeferredCoroutine, await() = 42
coroutineScope returned: scope result
withContext returned: context result
runBlocking returned: runBlocking result
```

| Builder | Returns | Blocks the thread? | Waits for children? |
|---|---|---|---|
| `runBlocking` | result of its lambda | Yes | Yes |
| `launch` | `Job` | No | No (the parent waits for it) |
| `async` | `Deferred<T>` | No | No (the parent waits for it) |
| `coroutineScope` | result of its lambda | No (suspends) | Yes |
| `withContext` | result of its lambda | No (suspends, switches context) | Yes |

## Question 14. Job or Deferred
```
computed inside launch: 42
join() returned: kotlin.Unit
async result: 42
```
`launch` returns a `Job` and cannot give a result. `Job` only represents the work (join, cancel). `Deferred<T>` is a `Job` that also holds a result, which you get with `await()`.

## Question 15. Three exports in a scope
```
Start
Y
Z
X
All done
```

---

## Suspending vs blocking
```kotlin
// BLOCKING: Thread.sleep(1000) holds the thread. It can do nothing else
// while it sleeps, so other coroutines on it must wait.
//
// SUSPENDING: delay(1000) pauses only the coroutine. The thread is given
// back and can run other coroutines. After 1000 ms the coroutine continues
// from the same place.
//
// Blocking = the thread waits. Suspending = only the coroutine waits.

fun main() = runBlocking {
    launch { delay(1000); println("suspended, the thread was free") }
    launch { println("I run while the other coroutine is suspended") }
}
```
