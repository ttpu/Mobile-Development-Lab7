import kotlinx.coroutines.*

// ---------- helpers used by some questions ----------

// Q3
suspend fun loadUser() {
    println("Step 1: load user")
    delay(300)
    checkPassword()
}

suspend fun checkPassword() {
    println("Step 2: check password")
    delay(300)
    openProfile()
}

suspend fun openProfile() {
    println("Step 3: open profile")
    delay(300)
    println("Profile opened")
}

// Q4
suspend fun fetchUser(): String {
    delay(100)
    return "Ada"
}

// BROKEN (does not compile):
// fun showUser() {
//     val user = fetchUser()
//     println(user)
// }

// Fix 1: make the caller suspend
suspend fun showUserSuspend() {
    println("Fix 1 (suspend): ${fetchUser()}")
}

// Fix 2: runBlocking
fun showUserBlocking() {
    val user = runBlocking { fetchUser() }
    println("Fix 2 (runBlocking): $user")
}

// Q5
suspend fun currentThreadName(): String {
    delay(10)
    return Thread.currentThread().name
}

// Q11
fun CoroutineScope.launchCounter(name: String, limit: Int): Job = launch {
    for (i in 1..limit) {
        delay(100)
        println("$name: $i")
    }
}

// Q12
fun CoroutineScope.greetInBackground(name: String): Job = launch {
    delay(200)
    println("Hello, $name (background)")
}

suspend fun greetAll(names: List<String>) = coroutineScope {
    for (name in names) {
        launch {
            delay(100)
            println("Hello, $name")
        }
    }
}

// ---------- questions ----------

fun q1() = runBlocking {
    launch {
        delay(1000)
        println("Coffee ready")
    }
    println("Order accepted")
}

fun q2() {
    println("with delay:")
    runBlocking {
        launch { println("espresso start"); delay(300); println("espresso end") }
        launch { println("tea start"); delay(100); println("tea end") }
        launch { println("latte start"); delay(200); println("latte end") }
    }
    println("with Thread.sleep:")
    runBlocking {
        launch { println("espresso start"); Thread.sleep(300); println("espresso end") }
        launch { println("tea start"); Thread.sleep(100); println("tea end") }
        launch { println("latte start"); Thread.sleep(200); println("latte end") }
    }
}

fun q3() = runBlocking {
    loadUser()
    println("Login flow finished")
}

fun q4() = runBlocking {
    showUserSuspend()
    showUserBlocking()
}

fun q5() = runBlocking {
    println("Before the call: ${Thread.currentThread().name}")
    val name = currentThreadName()
    println("Returned: $name")
}

fun q6() = runBlocking {
    for (i in 1..10) {
        launch {
            println("download $i started on ${Thread.currentThread().name}")
            delay(500L + i * 10)
            println("download $i finished")
        }
    }
}

fun q7() = runBlocking {
    println("1")
    launch {
        println("2")
        delay(100)
        println("3")
    }
    println("4")
    delay(50)
    println("5")
}

fun q8() = runBlocking {
    val parent = launch {
        launch {
            delay(200)
            println("child done")
        }
        println("parent body done")
    }
    parent.join()
    println("report completed")
}

fun q9() = runBlocking {
    val parent = launch {
        launch {
            try {
                println("request 1 started")
                delay(1000)
                println("request 1 finished")
            } finally {
                println("request 1 cleanup")
            }
        }
        launch {
            try {
                println("request 2 started")
                delay(1000)
                println("request 2 finished")
            } finally {
                println("request 2 cleanup")
            }
        }
    }
    delay(100)
    parent.cancelAndJoin()
    println("end")
}

fun q10() = runBlocking {
    coroutineScope {
        launch { delay(200); println("avatar loaded") }
        launch { delay(100); println("settings loaded") }
    }
    println("Profile ready")

    launch {
        delay(100)
        println("late coroutine")
    }
    println("end of main")
}

fun q11() = runBlocking {
    coroutineScope {
        launchCounter("A", 3)
        launchCounter("B", 5)
        println("launched")
    }
}

fun q12() = runBlocking {
    greetInBackground("Ada")
    println("after greetInBackground")

    greetAll(listOf("Linus", "Grace"))
    println("after greetAll")
}

fun q13() {
    val fromRunBlocking = runBlocking {
        val job = launch {
            delay(100)
            println("inside launch")
        }
        println("launch returned: ${job::class.simpleName}")

        val deferred = async {
            delay(100)
            6 * 7
        }
        println("async returned: ${deferred::class.simpleName}, await() = ${deferred.await()}")

        val fromScope = coroutineScope {
            delay(50)
            "scope result"
        }
        println("coroutineScope returned: $fromScope")

        val fromContext = withContext(Dispatchers.Default) {
            delay(50)
            "context result"
        }
        println("withContext returned: $fromContext")

        "runBlocking result"
    }
    println("runBlocking returned: $fromRunBlocking")
}

fun q14() = runBlocking {
    // launch: returns Job, the value is lost
    val job: Job = launch {
        println("computed inside launch: ${6 * 7}")
    }
    // val value: Int = job   // does not compile
    println("join() returned: ${job.join()}")

    // async: returns Deferred<Int>
    val deferred: Deferred<Int> = async { 6 * 7 }
    println("async result: ${deferred.await()}")
}

fun q15() = runBlocking {
    println("Start")
    coroutineScope {
        launch { delay(300); println("X") }
        launch { delay(100); println("Y") }
        launch { delay(200); println("Z") }
    }
    println("All done")
}

// ---------- run everything ----------

fun main() {
    val questions = listOf(
        ::q1, ::q2, ::q3, ::q4, ::q5, ::q6, ::q7, ::q8,
        ::q9, ::q10, ::q11, ::q12, ::q13, ::q14, ::q15
    )
    questions.forEachIndexed { index, question ->
        println("===== Question ${index + 1} =====")
        question()
    }
}
