rootProject.name = "coroutines-lab"
